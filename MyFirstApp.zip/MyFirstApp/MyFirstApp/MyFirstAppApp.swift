//
//  MyFirstAppApp.swift
//  MyFirstApp
//
//  Created by Eliana Kim on 4/2/25.
//

import SwiftUI

@main
struct MyFirstAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
