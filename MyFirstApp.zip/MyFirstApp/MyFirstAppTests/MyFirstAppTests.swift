//
//  MyFirstAppTests.swift
//  MyFirstAppTests
//
//  Created by Eliana Kim on 4/2/25.
//

import Testing

struct MyFirstAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
